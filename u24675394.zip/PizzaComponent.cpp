#include "PizzaComponent.h"

PizzaComponent::PizzaComponent(std::string name, double price)
    : name(name), price(price) {}
    
PizzaComponent::~PizzaComponent() {}