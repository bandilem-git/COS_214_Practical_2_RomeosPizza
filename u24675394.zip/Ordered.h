#ifndef ORDERED_H
#define ORDERED_H

#include "PizzaState.h"
#include "PizzaStateContext.h"

class Ordered : public PizzaState {
public:
    Ordered(); // heatLevel -2
    void handle(PizzaStateContext* context) override;
    std::string getName();
};

#endif
