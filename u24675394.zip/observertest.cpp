#include <iostream>
#include <vector>
#include <string>

#include "Menus.h"
#include "Observer.h"
#include "PizzaMenu.h"
#include "SpecialsMenu.h"
#include "Customer.h"
#include "Website.h"
#include "BasePizza.h"
#include "ToppingGroup.h"

// int main(){
//     // ToppingGroup* toppingroup1 = new ToppingGroup("tomato", 10.50);
//     // ToppingGroup* toppingroup2 = new ToppingGroup("BBQ", 10.50);
//     // Pizza* p1 = new BasePizza("Chicken", 100,toppingroup1);
//     // Pizza* p2 = new BasePizza("Beef", 120,toppingroup2);

//     // Menus* menu[2];
//     // menu[0] = new PizzaMenu();
//     // menu[1] = new SpecialsMenu();

//     // Observer* observer[2];
//     // observer[0] = new Customer();
//     // observer[1] = new Website();

//     // menu[0]->addObserver(observer[0]);
//     // menu[0]->addObserver(observer[1]);
//     // menu[1]->addObserver(observer[0]);
//     // menu[1]->addObserver(observer[1]);

//     // menu[0]->addPizza(p1);
//     // menu[0]->addPizza(p2);
//     // menu[1]->addPizza(p1);
//     // menu[1]->addPizza(p2);

//     // menu[0]->removePizza(p1);
//     // menu[0]->removePizza(p2);
//     // menu[1]->removePizza(p1);
//     // menu[1]->removePizza(p2);

//     // menu[0]->removeObserver(observer[0]);
//     // menu[0]->removeObserver(observer[1]);
//     // menu[1]->removeObserver(observer[0]);
//     // menu[1]->removeObserver(observer[1]);

//     // delete menu[0];
//     // delete menu[1];
//     // delete observer[0];
//     // delete observer[1];
//     // delete p1;
//     // delete p2;
//     // delete toppingroup;

//     return 0;
// }